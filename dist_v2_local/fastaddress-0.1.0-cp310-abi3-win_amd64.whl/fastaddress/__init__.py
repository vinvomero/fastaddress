from .fastaddress import *

__doc__ = fastaddress.__doc__
if hasattr(fastaddress, "__all__"):
    __all__ = fastaddress.__all__